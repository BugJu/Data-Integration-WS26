/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.bloomfilter;

import java.util.function.IntPredicate;
import java.util.function.LongPredicate;
import org.apache.commons.collections4.bloomfilter.BitMapExtractor;
import org.apache.commons.collections4.bloomfilter.BloomFilter;
import org.apache.commons.collections4.bloomfilter.Hasher;
import org.apache.commons.collections4.bloomfilter.IndexExtractor;
import org.apache.commons.collections4.bloomfilter.LongBiPredicate;
import org.apache.commons.collections4.bloomfilter.Shape;

public abstract class WrappedBloomFilter
implements BloomFilter {
    private final BloomFilter wrapped;

    public WrappedBloomFilter(BloomFilter bf) {
        this.wrapped = bf;
    }

    @Override
    public long[] asBitMapArray() {
        return this.wrapped.asBitMapArray();
    }

    @Override
    public int[] asIndexArray() {
        return this.wrapped.asIndexArray();
    }

    @Override
    public int cardinality() {
        return this.wrapped.cardinality();
    }

    @Override
    public int characteristics() {
        return this.wrapped.characteristics();
    }

    @Override
    public void clear() {
        this.wrapped.clear();
    }

    @Override
    public boolean contains(BitMapExtractor bitMapExtractor) {
        return this.wrapped.contains(bitMapExtractor);
    }

    @Override
    public boolean contains(BloomFilter other) {
        return this.wrapped.contains(other);
    }

    @Override
    public boolean contains(Hasher hasher) {
        return this.wrapped.contains(hasher);
    }

    @Override
    public boolean contains(IndexExtractor indexExtractor) {
        return this.wrapped.contains(indexExtractor);
    }

    @Override
    public int estimateIntersection(BloomFilter other) {
        return this.wrapped.estimateIntersection(other);
    }

    @Override
    public int estimateN() {
        return this.wrapped.estimateN();
    }

    @Override
    public int estimateUnion(BloomFilter other) {
        return this.wrapped.estimateUnion(other);
    }

    @Override
    public boolean processBitMaps(LongPredicate predicate) {
        return this.wrapped.processBitMaps(predicate);
    }

    @Override
    public boolean processBitMapPairs(BitMapExtractor other, LongBiPredicate func) {
        return this.wrapped.processBitMapPairs(other, func);
    }

    @Override
    public boolean processIndices(IntPredicate predicate) {
        return this.wrapped.processIndices(predicate);
    }

    @Override
    public Shape getShape() {
        return this.wrapped.getShape();
    }

    protected BloomFilter getWrapped() {
        return this.wrapped;
    }

    @Override
    public boolean isFull() {
        return this.wrapped.isFull();
    }

    @Override
    public boolean merge(BitMapExtractor bitMapExtractor) {
        return this.wrapped.merge(bitMapExtractor);
    }

    @Override
    public boolean merge(BloomFilter other) {
        return this.wrapped.merge(other);
    }

    @Override
    public boolean merge(Hasher hasher) {
        return this.wrapped.merge(hasher);
    }

    @Override
    public boolean merge(IndexExtractor indexExtractor) {
        return this.wrapped.merge(indexExtractor);
    }
}

