/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.bloomfilter;

import java.util.Arrays;

final class IndexUtils {
    static final int MAX_ARRAY_SIZE = 0x7FFFFFF7;

    static int[] ensureCapacityForAdd(int[] array, int index) {
        if (index >= array.length) {
            return Arrays.copyOf(array, (int)Math.min(0x7FFFFFF7L, Math.max((long)array.length * 2L, (long)(index + 1))));
        }
        return array;
    }

    private IndexUtils() {
    }
}

