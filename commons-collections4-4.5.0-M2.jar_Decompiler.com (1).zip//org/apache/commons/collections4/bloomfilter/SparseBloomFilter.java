/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.bloomfilter;

import java.util.Objects;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.function.IntPredicate;
import java.util.function.LongPredicate;
import org.apache.commons.collections4.bloomfilter.BitMapExtractor;
import org.apache.commons.collections4.bloomfilter.BitMaps;
import org.apache.commons.collections4.bloomfilter.BloomFilter;
import org.apache.commons.collections4.bloomfilter.Hasher;
import org.apache.commons.collections4.bloomfilter.IndexExtractor;
import org.apache.commons.collections4.bloomfilter.Shape;

public final class SparseBloomFilter
implements BloomFilter {
    private final TreeSet<Integer> indices;
    private final Shape shape;

    public SparseBloomFilter(Shape shape) {
        Objects.requireNonNull(shape, "shape");
        this.shape = shape;
        this.indices = new TreeSet();
    }

    private SparseBloomFilter(SparseBloomFilter source) {
        this.shape = source.shape;
        this.indices = new TreeSet<Integer>((SortedSet<Integer>)source.indices);
    }

    private boolean add(int idx) {
        this.indices.add(idx);
        return true;
    }

    @Override
    public long[] asBitMapArray() {
        long[] result = new long[BitMaps.numberOfBitMaps(this.shape.getNumberOfBits())];
        for (int i : this.indices) {
            BitMaps.set(result, i);
        }
        return result;
    }

    @Override
    public int cardinality() {
        return this.indices.size();
    }

    @Override
    public int characteristics() {
        return 1;
    }

    @Override
    public void clear() {
        this.indices.clear();
    }

    @Override
    public boolean contains(BitMapExtractor bitMapExtractor) {
        return this.contains(IndexExtractor.fromBitMapExtractor(bitMapExtractor));
    }

    @Override
    public boolean contains(IndexExtractor indexExtractor) {
        return indexExtractor.processIndices(this.indices::contains);
    }

    public SparseBloomFilter copy() {
        return new SparseBloomFilter(this);
    }

    @Override
    public boolean processBitMaps(LongPredicate consumer) {
        Objects.requireNonNull(consumer, "consumer");
        int limit = BitMaps.numberOfBitMaps(this.shape.getNumberOfBits());
        long bitMap = 0L;
        int idx = 0;
        for (int i : this.indices) {
            while (BitMaps.getLongIndex(i) != idx) {
                if (!consumer.test(bitMap)) {
                    return false;
                }
                bitMap = 0L;
                ++idx;
            }
            bitMap |= BitMaps.getLongBit(i);
        }
        if (!consumer.test(bitMap)) {
            return false;
        }
        ++idx;
        while (idx < limit) {
            if (!consumer.test(0L)) {
                return false;
            }
            ++idx;
        }
        return true;
    }

    @Override
    public boolean processIndices(IntPredicate consumer) {
        Objects.requireNonNull(consumer, "consumer");
        for (int value : this.indices) {
            if (consumer.test(value)) continue;
            return false;
        }
        return true;
    }

    @Override
    public Shape getShape() {
        return this.shape;
    }

    @Override
    public boolean isEmpty() {
        return this.indices.isEmpty();
    }

    @Override
    public boolean merge(BitMapExtractor bitMapExtractor) {
        Objects.requireNonNull(bitMapExtractor, "bitMapExtractor");
        return this.merge(IndexExtractor.fromBitMapExtractor(bitMapExtractor));
    }

    @Override
    public boolean merge(BloomFilter other) {
        Objects.requireNonNull(other, "other");
        IndexExtractor indexExtractor = (other.characteristics() & 1) != 0 ? other : IndexExtractor.fromBitMapExtractor(other);
        this.merge(indexExtractor);
        return true;
    }

    @Override
    public boolean merge(Hasher hasher) {
        Objects.requireNonNull(hasher, "hasher");
        this.merge(hasher.indices(this.shape));
        return true;
    }

    @Override
    public boolean merge(IndexExtractor indexExtractor) {
        Objects.requireNonNull(indexExtractor, "indexExtractor");
        indexExtractor.processIndices(this::add);
        if (!this.indices.isEmpty()) {
            if (this.indices.last() >= this.shape.getNumberOfBits()) {
                throw new IllegalArgumentException(String.format("Value in list %s is greater than maximum value (%s)", this.indices.last(), this.shape.getNumberOfBits() - 1));
            }
            if (this.indices.first() < 0) {
                throw new IllegalArgumentException(String.format("Value in list %s is less than 0", this.indices.first()));
            }
        }
        return true;
    }
}

