/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.bloomfilter;

@FunctionalInterface
public interface LongBiPredicate {
    public boolean test(long var1, long var3);
}

