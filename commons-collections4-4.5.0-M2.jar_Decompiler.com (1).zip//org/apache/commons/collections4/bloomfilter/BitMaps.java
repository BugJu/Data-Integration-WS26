/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.bloomfilter;

public class BitMaps {
    private static final int DIVIDE_BY_64 = 6;

    public static boolean contains(long[] bitMaps, int bitIndex) {
        return (bitMaps[BitMaps.getLongIndex(bitIndex)] & BitMaps.getLongBit(bitIndex)) != 0L;
    }

    public static long getLongBit(int bitIndex) {
        return 1L << bitIndex;
    }

    public static int getLongIndex(int bitIndex) {
        return bitIndex >> 6;
    }

    public static int mod(long dividend, int divisor) {
        long quotient = (dividend >>> 1) / (long)divisor << 1;
        long remainder = dividend - quotient * (long)divisor;
        return (int)(remainder >= (long)divisor ? remainder - (long)divisor : remainder);
    }

    public static int numberOfBitMaps(int numberOfBits) {
        return (numberOfBits - 1 >> 6) + 1;
    }

    public static void set(long[] bitMaps, int bitIndex) {
        int n = BitMaps.getLongIndex(bitIndex);
        bitMaps[n] = bitMaps[n] | BitMaps.getLongBit(bitIndex);
    }

    private BitMaps() {
    }
}

