/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4;

import java.util.function.Function;

@Deprecated
public interface Transformer<T, R>
extends Function<T, R> {
    @Override
    default public R apply(T t) {
        return this.transform(t);
    }

    public R transform(T var1);
}

