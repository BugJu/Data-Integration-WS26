/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4;

@Deprecated
public interface Predicate<T>
extends java.util.function.Predicate<T> {
    public boolean evaluate(T var1);

    @Override
    default public boolean test(T t) {
        return this.evaluate(t);
    }
}

