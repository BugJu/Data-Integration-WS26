/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.keyvalue;

import java.util.Map;
import java.util.Objects;
import org.apache.commons.collections4.KeyValue;

public abstract class AbstractMapEntryDecorator<K, V>
implements Map.Entry<K, V>,
KeyValue<K, V> {
    private final Map.Entry<K, V> entry;

    public AbstractMapEntryDecorator(Map.Entry<K, V> entry) {
        this.entry = Objects.requireNonNull(entry, "entry");
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        return this.entry.equals(object);
    }

    @Override
    public K getKey() {
        return this.entry.getKey();
    }

    protected Map.Entry<K, V> getMapEntry() {
        return this.entry;
    }

    @Override
    public V getValue() {
        return this.entry.getValue();
    }

    @Override
    public int hashCode() {
        return this.entry.hashCode();
    }

    @Override
    public V setValue(V object) {
        return this.entry.setValue(object);
    }

    public String toString() {
        return this.entry.toString();
    }
}

