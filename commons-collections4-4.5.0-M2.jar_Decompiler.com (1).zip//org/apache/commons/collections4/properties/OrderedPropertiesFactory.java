/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.properties;

import org.apache.commons.collections4.properties.AbstractPropertiesFactory;
import org.apache.commons.collections4.properties.OrderedProperties;

public class OrderedPropertiesFactory
extends AbstractPropertiesFactory<OrderedProperties> {
    public static final OrderedPropertiesFactory INSTANCE = new OrderedPropertiesFactory();

    private OrderedPropertiesFactory() {
    }

    @Override
    protected OrderedProperties createProperties() {
        return new OrderedProperties();
    }
}

