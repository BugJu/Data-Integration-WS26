/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.properties;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.InvalidPropertiesFormatException;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import org.apache.commons.collections4.properties.AbstractPropertiesFactory;

public class PropertiesFactory
extends AbstractPropertiesFactory<Properties> {
    public static final Properties EMPTY_PROPERTIES = new EmptyProperties();
    public static final PropertiesFactory INSTANCE = new PropertiesFactory();

    private PropertiesFactory() {
    }

    @Override
    protected Properties createProperties() {
        return new Properties();
    }

    private static final class EmptyProperties
    extends Properties {
        private static final long serialVersionUID = 1L;

        private EmptyProperties() {
        }

        @Override
        public synchronized void clear() {
        }

        @Override
        public synchronized Object compute(Object key, BiFunction<? super Object, ? super Object, ? extends Object> remappingFunction) {
            Objects.requireNonNull(key);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized Object computeIfAbsent(Object key, Function<? super Object, ? extends Object> mappingFunction) {
            Objects.requireNonNull(key);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized Object computeIfPresent(Object key, BiFunction<? super Object, ? super Object, ? extends Object> remappingFunction) {
            Objects.requireNonNull(key);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized boolean contains(Object value) {
            return false;
        }

        @Override
        public synchronized boolean containsKey(Object key) {
            return false;
        }

        @Override
        public boolean containsValue(Object value) {
            return false;
        }

        @Override
        public synchronized Enumeration<Object> elements() {
            return Collections.emptyEnumeration();
        }

        @Override
        public Set<Map.Entry<Object, Object>> entrySet() {
            return Collections.emptySet();
        }

        @Override
        public synchronized boolean equals(Object o) {
            return o instanceof Properties && ((Properties)o).isEmpty();
        }

        @Override
        public synchronized void forEach(BiConsumer<? super Object, ? super Object> action) {
            Objects.requireNonNull(action);
        }

        @Override
        public synchronized Object get(Object key) {
            return null;
        }

        @Override
        public synchronized Object getOrDefault(Object key, Object defaultValue) {
            return defaultValue;
        }

        @Override
        public String getProperty(String key) {
            return null;
        }

        @Override
        public String getProperty(String key, String defaultValue) {
            return defaultValue;
        }

        @Override
        public synchronized int hashCode() {
            return 0;
        }

        @Override
        public synchronized boolean isEmpty() {
            return true;
        }

        @Override
        public synchronized Enumeration<Object> keys() {
            return Collections.emptyEnumeration();
        }

        @Override
        public Set<Object> keySet() {
            return Collections.emptySet();
        }

        @Override
        public synchronized void load(InputStream inStream) throws IOException {
            Objects.requireNonNull(inStream);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized void load(Reader reader) throws IOException {
            Objects.requireNonNull(reader);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized void loadFromXML(InputStream in) throws IOException, InvalidPropertiesFormatException {
            Objects.requireNonNull(in);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized Object merge(Object key, Object value, BiFunction<? super Object, ? super Object, ? extends Object> remappingFunction) {
            Objects.requireNonNull(key);
            Objects.requireNonNull(value);
            throw new UnsupportedOperationException();
        }

        @Override
        public Enumeration<?> propertyNames() {
            return Collections.emptyEnumeration();
        }

        @Override
        public synchronized Object put(Object key, Object value) {
            Objects.requireNonNull(key);
            Objects.requireNonNull(value);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized void putAll(Map<? extends Object, ? extends Object> t) {
            Objects.requireNonNull(t);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized Object putIfAbsent(Object key, Object value) {
            Objects.requireNonNull(key);
            Objects.requireNonNull(value);
            throw new UnsupportedOperationException();
        }

        @Override
        protected void rehash() {
        }

        @Override
        public synchronized Object remove(Object key) {
            Objects.requireNonNull(key);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized boolean remove(Object key, Object value) {
            Objects.requireNonNull(key);
            Objects.requireNonNull(value);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized Object replace(Object key, Object value) {
            Objects.requireNonNull(key);
            Objects.requireNonNull(value);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized boolean replace(Object key, Object oldValue, Object newValue) {
            Objects.requireNonNull(key);
            Objects.requireNonNull(oldValue);
            Objects.requireNonNull(newValue);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized void replaceAll(BiFunction<? super Object, ? super Object, ? extends Object> function) {
            Objects.requireNonNull(function);
            throw new UnsupportedOperationException();
        }

        @Override
        public void save(OutputStream out, String comments) {
            super.save(out, comments);
        }

        @Override
        public synchronized Object setProperty(String key, String value) {
            Objects.requireNonNull(key);
            Objects.requireNonNull(value);
            throw new UnsupportedOperationException();
        }

        @Override
        public synchronized int size() {
            return 0;
        }

        @Override
        public Set<String> stringPropertyNames() {
            return Collections.emptySet();
        }

        @Override
        public synchronized String toString() {
            return super.toString();
        }

        @Override
        public Collection<Object> values() {
            return Collections.emptyList();
        }
    }
}

