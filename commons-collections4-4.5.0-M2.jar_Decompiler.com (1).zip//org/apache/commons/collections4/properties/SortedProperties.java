/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4.properties;

import java.util.AbstractMap;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.collections4.iterators.IteratorEnumeration;

public class SortedProperties
extends Properties {
    private static final long serialVersionUID = 1L;

    @Override
    public Set<Map.Entry<Object, Object>> entrySet() {
        Stream<AbstractMap.SimpleEntry> stream = this.sortedKeys().map(k -> new AbstractMap.SimpleEntry<String, String>((String)k, this.getProperty((String)k)));
        return stream.collect(Collectors.toCollection(LinkedHashSet::new));
    }

    @Override
    public synchronized Enumeration<Object> keys() {
        return new IteratorEnumeration<Object>(this.sortedKeys().collect(Collectors.toList()).iterator());
    }

    private Stream<String> sortedKeys() {
        return this.keySet().stream().map(Object::toString).sorted();
    }
}

