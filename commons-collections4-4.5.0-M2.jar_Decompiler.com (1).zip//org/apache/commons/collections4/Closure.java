/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4;

import java.util.function.Consumer;

@Deprecated
public interface Closure<T>
extends Consumer<T> {
    @Override
    default public void accept(T input) {
        this.execute(input);
    }

    public void execute(T var1);
}

