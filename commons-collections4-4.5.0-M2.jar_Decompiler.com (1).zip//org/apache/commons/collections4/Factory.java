/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package org.apache.commons.collections4;

import java.util.function.Supplier;

@Deprecated
public interface Factory<T>
extends Supplier<T> {
    public T create();

    @Override
    default public T get() {
        return this.create();
    }
}

